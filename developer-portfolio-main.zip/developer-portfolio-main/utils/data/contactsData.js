export const contactsData = {
    email: 'abusaid7388@gmail.com',
    phone: '+8801608797655',
    address: 'Middle Badda, Dhaka, Bangladesh - 1212 ',
    github: 'https://github.com/said7388',
    facebook: 'https://www.facebook.com/abusaid.riyaz/',
    linkedIn: 'https://www.linkedin.com/in/abu-said-bd/',
    twitter: 'https://twitter.com/said7388',
    stackOverflow: 'https://stackoverflow.com/users/16840768/abu-said',
    devUsername: "said7388"
}