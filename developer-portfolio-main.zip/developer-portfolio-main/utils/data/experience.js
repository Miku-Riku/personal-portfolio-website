export const experiences = [
  {
    id: 1,
    title: 'Software Engineer I',
    company: "Teton Private Ltd.",
    duration: "(Jan 2022 - Present)"
  },
  {
    id: 2,
    title: "FullStack Developer",
    company: "Fiverr (freelance)",
    duration: "(Jun 2021 - Jan 2022)"
  },
  {
    id: 3,
    title: "Self Employed",
    company: "Code and build something in everyday.",
    duration: "(Jan 2018 - Present)"
  }
]